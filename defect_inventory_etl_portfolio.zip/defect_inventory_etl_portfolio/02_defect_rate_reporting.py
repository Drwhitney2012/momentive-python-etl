"""
Portfolio-safe example: build defect-rate reporting dataset.

This script combines clean defect events with production output to calculate
defect rates by plant, production line, material, and production date.
"""

from pathlib import Path
import pandas as pd


DEFECT_PATH = Path("data/silver/defect_events_clean.csv")
PRODUCTION_PATH = Path("data/raw/production_output.csv")
GOLD_PATH = Path("data/gold/defect_rate_reporting.csv")


def build_defect_rate_report(defects: pd.DataFrame, production: pd.DataFrame) -> pd.DataFrame:
    defects = defects.copy()
    production = production.copy()

    defects["inspection_date"] = pd.to_datetime(defects["inspection_date"])
    production["production_date"] = pd.to_datetime(production["production_date"])

    defect_summary = (
        defects.groupby(
            ["plant_code", "production_line", "material_id", "inspection_date"],
            as_index=False,
        )
        .agg(
            total_defective_units=("quantity_defective", "sum"),
            defect_event_count=("defect_id", "nunique"),
            max_severity_rank=("severity_rank", "max"),
        )
    )

    production.columns = [c.strip().lower() for c in production.columns]
    for col in ["plant_code", "production_line", "material_id"]:
        production[col] = production[col].astype(str).str.strip().str.upper()

    report = defect_summary.merge(
        production,
        left_on=["plant_code", "production_line", "material_id", "inspection_date"],
        right_on=["plant_code", "production_line", "material_id", "production_date"],
        how="left",
    )

    report["units_produced"] = report["units_produced"].fillna(0)

    report["defect_rate"] = report.apply(
        lambda row: 0
        if row["units_produced"] == 0
        else row["total_defective_units"] / row["units_produced"],
        axis=1,
    )

    report["defects_per_1000_units"] = report["defect_rate"] * 1000

    report["quality_status"] = report["defects_per_1000_units"].apply(
        lambda x: "REVIEW" if x > 10 else "PASS"
    )

    return report.drop(columns=["production_date"])


if __name__ == "__main__":
    defects = pd.read_csv(DEFECT_PATH)
    production = pd.read_csv(PRODUCTION_PATH)

    report = build_defect_rate_report(defects, production)

    GOLD_PATH.parent.mkdir(parents=True, exist_ok=True)
    report.to_csv(GOLD_PATH, index=False)

    print(f"Created {GOLD_PATH} with {len(report):,} reporting rows")
