"""
Portfolio-safe example: reusable quality checks for defect and inventory data.
"""

from pathlib import Path
import pandas as pd


def check_required_columns(df: pd.DataFrame, required_columns: list[str], dataset_name: str) -> list[dict]:
    results = []
    for col in required_columns:
        results.append({
            "dataset": dataset_name,
            "check_name": f"Required column exists: {col}",
            "failed_count": 0 if col in df.columns else 1,
            "status": "PASS" if col in df.columns else "FAIL",
        })
    return results


def check_nulls(df: pd.DataFrame, columns: list[str], dataset_name: str) -> list[dict]:
    results = []
    for col in columns:
        failed_count = df[col].isna().sum() if col in df.columns else 1
        results.append({
            "dataset": dataset_name,
            "check_name": f"Null check: {col}",
            "failed_count": int(failed_count),
            "status": "PASS" if failed_count == 0 else "FAIL",
        })
    return results


def check_negative_values(df: pd.DataFrame, columns: list[str], dataset_name: str) -> list[dict]:
    results = []
    for col in columns:
        failed_count = (df[col] < 0).sum() if col in df.columns else 1
        results.append({
            "dataset": dataset_name,
            "check_name": f"Negative value check: {col}",
            "failed_count": int(failed_count),
            "status": "PASS" if failed_count == 0 else "FAIL",
        })
    return results


if __name__ == "__main__":
    defect_path = Path("data/silver/defect_events_clean.csv")
    inventory_path = Path("data/silver/inventory_snapshot_clean.csv")

    results = []

    if defect_path.exists():
        defects = pd.read_csv(defect_path)
        results += check_required_columns(
            defects,
            ["defect_id", "plant_code", "production_line", "material_id", "quantity_defective"],
            "defect_events_clean",
        )
        results += check_nulls(
            defects,
            ["defect_id", "plant_code", "material_id", "inspection_date"],
            "defect_events_clean",
        )
        results += check_negative_values(
            defects,
            ["quantity_defective"],
            "defect_events_clean",
        )

    if inventory_path.exists():
        inventory = pd.read_csv(inventory_path)
        results += check_required_columns(
            inventory,
            ["snapshot_date", "plant_code", "warehouse_code", "material_id", "on_hand_qty"],
            "inventory_snapshot_clean",
        )
        results += check_nulls(
            inventory,
            ["snapshot_date", "plant_code", "warehouse_code", "material_id"],
            "inventory_snapshot_clean",
        )
        results += check_negative_values(
            inventory,
            ["on_hand_qty", "allocated_qty", "reorder_point", "standard_cost"],
            "inventory_snapshot_clean",
        )

    quality_results = pd.DataFrame(results)
    print(quality_results)

    Path("data/gold").mkdir(parents=True, exist_ok=True)
    quality_results.to_csv("data/gold/data_quality_results.csv", index=False)

    if not quality_results.empty and (quality_results["status"] == "FAIL").any():
        raise SystemExit("One or more data quality checks failed.")
