"""
Portfolio-safe example: build inventory reporting dataset.

This script creates a Gold-layer reporting dataset with stock status,
available quantity, reorder flags, and inventory value.
"""

from pathlib import Path
import pandas as pd


SILVER_PATH = Path("data/silver/inventory_snapshot_clean.csv")
GOLD_PATH = Path("data/gold/inventory_reporting.csv")


def build_inventory_report(inventory: pd.DataFrame) -> pd.DataFrame:
    report = inventory.copy()

    report["reorder_flag"] = report["available_qty"] < report["reorder_point"]

    report["shortage_qty"] = report.apply(
        lambda row: max(row["reorder_point"] - row["available_qty"], 0),
        axis=1,
    )

    report["stock_status"] = report.apply(
        lambda row: "REORDER"
        if row["reorder_flag"]
        else "HEALTHY",
        axis=1,
    )

    summary = (
        report.groupby(["snapshot_date", "plant_code", "warehouse_code"], as_index=False)
        .agg(
            material_count=("material_id", "nunique"),
            total_on_hand_qty=("on_hand_qty", "sum"),
            total_available_qty=("available_qty", "sum"),
            total_inventory_value=("inventory_value", "sum"),
            reorder_item_count=("reorder_flag", "sum"),
            total_shortage_qty=("shortage_qty", "sum"),
        )
    )

    return summary


if __name__ == "__main__":
    inventory = pd.read_csv(SILVER_PATH)
    report = build_inventory_report(inventory)

    GOLD_PATH.parent.mkdir(parents=True, exist_ok=True)
    report.to_csv(GOLD_PATH, index=False)

    print(f"Created {GOLD_PATH} with {len(report):,} reporting rows")
