"""
Portfolio-safe example: clean manufacturing defect event data.

This script reads raw inspection/defect records and creates a standardized
Silver-layer dataset that can support operational quality dashboards.
"""

from pathlib import Path
import pandas as pd


RAW_PATH = Path("data/raw/defect_events.csv")
SILVER_PATH = Path("data/silver/defect_events_clean.csv")


def clean_defect_events(df: pd.DataFrame) -> pd.DataFrame:
    cleaned = df.copy()

    cleaned.columns = [c.strip().lower() for c in cleaned.columns]

    text_columns = [
        "defect_id",
        "plant_code",
        "production_line",
        "material_id",
        "defect_type",
        "severity",
        "shift",
        "work_order_id",
    ]

    for col in text_columns:
        cleaned[col] = cleaned[col].astype(str).str.strip().str.upper()

    cleaned["inspection_date"] = pd.to_datetime(
        cleaned["inspection_date"], errors="coerce"
    )

    cleaned["quantity_defective"] = pd.to_numeric(
        cleaned["quantity_defective"], errors="coerce"
    ).fillna(0)

    severity_rank = {
        "MINOR": 1,
        "MAJOR": 2,
        "CRITICAL": 3,
    }

    cleaned["severity_rank"] = cleaned["severity"].map(severity_rank).fillna(0).astype(int)

    cleaned = cleaned.drop_duplicates(subset=["defect_id"])

    return cleaned


if __name__ == "__main__":
    raw = pd.read_csv(RAW_PATH)
    clean = clean_defect_events(raw)

    SILVER_PATH.parent.mkdir(parents=True, exist_ok=True)
    clean.to_csv(SILVER_PATH, index=False)

    print(f"Created {SILVER_PATH} with {len(clean):,} records")
