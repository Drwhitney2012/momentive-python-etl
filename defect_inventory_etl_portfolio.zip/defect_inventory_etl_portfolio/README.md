# Defect and Inventory Reporting ETL Portfolio

Sanitized Python ETL examples for manufacturing-style defect reporting and inventory reporting.  
These scripts are designed for a GitHub portfolio and demonstrate practical enterprise data engineering patterns.

## What This Demonstrates

- Python ETL development
- Pandas transformations
- Data quality validation
- Defect rate reporting
- Inventory availability reporting
- Reorder and shortage flags
- Curated Silver and Gold reporting layers
- BI-ready output datasets for Power BI or Tableau

## Folder Structure

```text
data/raw      Mock source extracts
data/silver   Cleaned and standardized datasets
data/gold     Reporting-ready analytical datasets
```

## Included Scripts

| Script | Purpose |
|---|---|
| `01_clean_defect_events.py` | Cleans raw defect inspection records |
| `02_defect_rate_reporting.py` | Builds defect-rate reporting by plant, line, material, and date |
| `03_clean_inventory_snapshot.py` | Cleans inventory snapshot data |
| `04_inventory_reporting.py` | Builds inventory reporting with available quantity, inventory value, and reorder flags |
| `05_data_quality_checks.py` | Runs reusable validation checks across defect and inventory datasets |

## Note

This project uses mock data only. It does not include proprietary employer data, credentials, or confidential business logic.
