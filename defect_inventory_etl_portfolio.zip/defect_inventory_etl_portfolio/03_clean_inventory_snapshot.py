"""
Portfolio-safe example: clean inventory snapshot data.

This script prepares raw warehouse inventory snapshots for reporting.
"""

from pathlib import Path
import pandas as pd


RAW_PATH = Path("data/raw/inventory_snapshot.csv")
SILVER_PATH = Path("data/silver/inventory_snapshot_clean.csv")


def clean_inventory_snapshot(df: pd.DataFrame) -> pd.DataFrame:
    cleaned = df.copy()

    cleaned.columns = [c.strip().lower() for c in cleaned.columns]

    for col in ["plant_code", "warehouse_code", "material_id"]:
        cleaned[col] = cleaned[col].astype(str).str.strip().str.upper()

    cleaned["snapshot_date"] = pd.to_datetime(cleaned["snapshot_date"], errors="coerce")

    numeric_columns = ["on_hand_qty", "allocated_qty", "reorder_point", "standard_cost"]
    for col in numeric_columns:
        cleaned[col] = pd.to_numeric(cleaned[col], errors="coerce").fillna(0)

    cleaned["available_qty"] = cleaned["on_hand_qty"] - cleaned["allocated_qty"]
    cleaned["inventory_value"] = cleaned["on_hand_qty"] * cleaned["standard_cost"]

    cleaned = cleaned.drop_duplicates(
        subset=["snapshot_date", "plant_code", "warehouse_code", "material_id"]
    )

    return cleaned


if __name__ == "__main__":
    raw = pd.read_csv(RAW_PATH)
    clean = clean_inventory_snapshot(raw)

    SILVER_PATH.parent.mkdir(parents=True, exist_ok=True)
    clean.to_csv(SILVER_PATH, index=False)

    print(f"Created {SILVER_PATH} with {len(clean):,} records")
