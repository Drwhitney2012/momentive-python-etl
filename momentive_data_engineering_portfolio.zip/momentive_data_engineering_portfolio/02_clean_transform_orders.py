"""
Portfolio-safe example: Bronze-to-Silver transformation.

This script standardizes raw manufacturing order data into a curated dataset
that could support Power BI, finance reporting, operational dashboards,
or downstream machine learning features.
"""

import pandas as pd


def clean_orders(df: pd.DataFrame) -> pd.DataFrame:
    """Clean and standardize SAP-style order records."""

    cleaned = df.copy()

    # Standardize column names
    cleaned.columns = [c.strip().lower() for c in cleaned.columns]

    # Trim and normalize string fields
    string_columns = ["order_id", "plant_code", "material_id", "customer_id", "currency"]
    for col in string_columns:
        cleaned[col] = cleaned[col].astype(str).str.strip().str.upper()

    # Convert dates
    cleaned["order_date"] = pd.to_datetime(cleaned["order_date"], errors="coerce")
    cleaned["requested_ship_date"] = pd.to_datetime(cleaned["requested_ship_date"], errors="coerce")
    cleaned["last_updated_timestamp"] = pd.to_datetime(
        cleaned["last_updated_timestamp"], errors="coerce"
    )

    # Convert numeric fields
    cleaned["order_quantity"] = pd.to_numeric(cleaned["order_quantity"], errors="coerce").fillna(0)
    cleaned["unit_price"] = pd.to_numeric(cleaned["unit_price"], errors="coerce").fillna(0)

    # Business calculations
    cleaned["gross_order_value"] = cleaned["order_quantity"] * cleaned["unit_price"]

    # Simple order status flag
    cleaned["ship_request_lag_days"] = (
        cleaned["requested_ship_date"] - cleaned["order_date"]
    ).dt.days

    cleaned["is_expedited"] = cleaned["ship_request_lag_days"].lt(3)

    # Remove fully duplicated records
    cleaned = cleaned.drop_duplicates()

    return cleaned


if __name__ == "__main__":
    raw = pd.read_csv("data/raw/sap_orders.csv")
    silver = clean_orders(raw)
    silver.to_csv("data/silver/orders_clean.csv", index=False)
    print(f"Created curated order dataset with {len(silver):,} records")
