# Momentive-Style Data Engineering Portfolio Examples

These are sanitized, portfolio-safe examples inspired by enterprise manufacturing data engineering work. 
They demonstrate Python-based ETL automation, validation, reconciliation, and curated reporting dataset preparation.

## Included Examples

1. `01_extract_sap_orders.py`  
   Simulates extracting SAP-style order data from a source file/API response.

2. `02_clean_transform_orders.py`  
   Standardizes raw operational data into a curated Silver-style dataset.

3. `03_reconcile_finance_ops.py`  
   Performs reconciliation checks between operational order data and finance totals.

4. `04_data_quality_checks.py`  
   Runs data quality validations such as null checks, duplicate checks, date checks, and value range checks.

5. `05_incremental_load_framework.py`  
   Demonstrates an incremental load pattern using a watermark date.

6. `sample_config.yaml`  
   Example configuration file for environment, source paths, and load settings.

## Technologies Represented

- Python
- Pandas
- SQL-style transformation logic
- Data quality checks
- Incremental ETL processing
- Finance and operations reporting support
- Bronze/Silver/Gold data architecture concepts

## Note

These examples are fully sanitized and use mock data structures only. They do not contain proprietary employer logic, credentials, or source data.
