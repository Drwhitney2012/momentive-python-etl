"""
Portfolio-safe example: Incremental load framework.

This script demonstrates a simple watermark-based incremental pattern.
In production, the watermark may live in a control table, metadata database,
or orchestration platform.
"""

from pathlib import Path
import pandas as pd


def read_watermark(watermark_path: str) -> pd.Timestamp:
    """Read the last successful load timestamp."""
    path = Path(watermark_path)

    if not path.exists():
        return pd.Timestamp("1900-01-01")

    return pd.to_datetime(path.read_text().strip())


def write_watermark(watermark_path: str, new_watermark: pd.Timestamp) -> None:
    """Write the latest successful load timestamp."""
    path = Path(watermark_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(str(new_watermark))


def get_incremental_records(
    df: pd.DataFrame,
    incremental_column: str,
    watermark: pd.Timestamp,
) -> pd.DataFrame:
    """Filter records updated after the last successful watermark."""
    data = df.copy()
    data[incremental_column] = pd.to_datetime(data[incremental_column], errors="coerce")

    return data[data[incremental_column] > watermark]


if __name__ == "__main__":
    source_file = "data/raw/sap_orders.csv"
    watermark_file = "metadata/order_watermark.txt"
    incremental_column = "last_updated_timestamp"

    raw_orders = pd.read_csv(source_file)

    last_watermark = read_watermark(watermark_file)
    incremental_orders = get_incremental_records(
        raw_orders,
        incremental_column,
        last_watermark,
    )

    print(f"Last watermark: {last_watermark}")
    print(f"Incremental records found: {len(incremental_orders):,}")

    if not incremental_orders.empty:
        new_watermark = pd.to_datetime(incremental_orders[incremental_column]).max()
        write_watermark(watermark_file, new_watermark)
        print(f"Updated watermark to: {new_watermark}")
