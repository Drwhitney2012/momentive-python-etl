"""
Portfolio-safe example: Finance-to-Operations reconciliation.

This script compares operational order totals against finance-reported totals
by plant and accounting period. This is a common data engineering pattern for
validating reporting accuracy before data is consumed by executive dashboards.
"""

import pandas as pd


def reconcile_orders_to_finance(
    orders_df: pd.DataFrame,
    finance_df: pd.DataFrame,
    tolerance: float = 1.00,
) -> pd.DataFrame:
    """Compare operational order value to finance totals by plant and month."""

    orders = orders_df.copy()
    finance = finance_df.copy()

    orders["order_date"] = pd.to_datetime(orders["order_date"])
    orders["accounting_period"] = orders["order_date"].dt.to_period("M").astype(str)

    ops_summary = (
        orders.groupby(["plant_code", "accounting_period"], as_index=False)
        .agg(operational_order_value=("gross_order_value", "sum"))
    )

    finance["plant_code"] = finance["plant_code"].astype(str).str.upper().str.strip()
    finance["accounting_period"] = finance["accounting_period"].astype(str)

    result = ops_summary.merge(
        finance,
        on=["plant_code", "accounting_period"],
        how="outer",
    )

    result["operational_order_value"] = result["operational_order_value"].fillna(0)
    result["finance_reported_value"] = result["finance_reported_value"].fillna(0)

    result["variance_amount"] = (
        result["operational_order_value"] - result["finance_reported_value"]
    )

    result["variance_pct"] = result.apply(
        lambda row: 0
        if row["finance_reported_value"] == 0
        else row["variance_amount"] / row["finance_reported_value"],
        axis=1,
    )

    result["reconciliation_status"] = result["variance_amount"].abs().apply(
        lambda x: "PASS" if x <= tolerance else "REVIEW"
    )

    return result.sort_values(["plant_code", "accounting_period"])


if __name__ == "__main__":
    orders = pd.read_csv("data/silver/orders_clean.csv")
    finance = pd.read_csv("data/raw/finance_totals.csv")

    reconciliation = reconcile_orders_to_finance(orders, finance)
    reconciliation.to_csv("data/gold/order_finance_reconciliation.csv", index=False)

    print(reconciliation)
