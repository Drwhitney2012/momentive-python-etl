"""
Portfolio-safe example: Data quality validation framework.

This script demonstrates reusable checks that can be run before promoting
data from staging into curated reporting layers.
"""

import pandas as pd


def run_quality_checks(df: pd.DataFrame) -> pd.DataFrame:
    """Return a data quality results table."""

    checks = []

    def add_check(check_name: str, failed_count: int, severity: str = "ERROR"):
        checks.append(
            {
                "check_name": check_name,
                "failed_count": int(failed_count),
                "status": "PASS" if failed_count == 0 else "FAIL",
                "severity": severity,
            }
        )

    add_check("Missing order_id", df["order_id"].isna().sum())
    add_check("Missing plant_code", df["plant_code"].isna().sum())
    add_check("Missing material_id", df["material_id"].isna().sum())
    add_check("Negative order quantity", (df["order_quantity"] < 0).sum())
    add_check("Negative unit price", (df["unit_price"] < 0).sum())
    add_check("Duplicate order_id", df.duplicated(subset=["order_id"]).sum(), "WARNING")

    order_dates = pd.to_datetime(df["order_date"], errors="coerce")
    ship_dates = pd.to_datetime(df["requested_ship_date"], errors="coerce")

    add_check("Invalid order_date", order_dates.isna().sum())
    add_check("Requested ship date before order date", (ship_dates < order_dates).sum())

    return pd.DataFrame(checks)


if __name__ == "__main__":
    orders = pd.read_csv("data/silver/orders_clean.csv")
    results = run_quality_checks(orders)

    print(results)

    if (results["status"] == "FAIL").any():
        raise SystemExit("Data quality checks failed. Review results before publishing.")
