"""
Portfolio-safe example: SAP-style order extraction.

This script simulates extracting manufacturing order data from a source system.
In a real enterprise environment, the source could be SAP, an API, flat files,
a SQL staging table, or cloud storage.
"""

from pathlib import Path
import pandas as pd


def extract_orders(source_path: str) -> pd.DataFrame:
    """Read raw SAP-style order data from a CSV file."""
    path = Path(source_path)

    if not path.exists():
        raise FileNotFoundError(f"Source file not found: {source_path}")

    df = pd.read_csv(path)

    expected_columns = {
        "order_id",
        "plant_code",
        "material_id",
        "customer_id",
        "order_date",
        "requested_ship_date",
        "order_quantity",
        "unit_price",
        "currency",
        "last_updated_timestamp",
    }

    missing = expected_columns - set(df.columns)
    if missing:
        raise ValueError(f"Missing expected source columns: {sorted(missing)}")

    return df


if __name__ == "__main__":
    orders = extract_orders("data/raw/sap_orders.csv")
    print(f"Extracted {len(orders):,} order records")
    print(orders.head())
